"""
Soit n un entier positif ou nul.
On considère un tableau trié contenant 2*n+1 nombres entiers :
* n paires de nombres
* 1 nombre "solitaire"

Par exemple avec n = 3, on a 3 paires d'entiers :
# indices  0  1  2  3  4  5  6
nombres = [2, 2, 5, 6, 6, 9, 9]
           AVANT | APRES

On peut tout d'abord constater que :
* AVANT le nombre solitaire, le premier membre de chaque couple est à un indice
  pair et le second à un indice impair
* APRES le nombre solitaire, le premier membre de chaque couple est à un indice
  impair et le second à un indice pair

Il est possible d'utiliser cette observation afin de mettre en place une
méthode "Diviser pour régner" inspirée de la recherche dichotomique :
* on définit une zone de recherche entre i_debut et i_fin ;
* on calcule l'indice de la valeur du milieu de la zone de recherche ;
* on compare la valeur à cette position et la suivante :
  * si l'indice du milieu est pair et que la valeur suivante est égale,
    le nombre solitaire se trouve plus loin ;
  * si l'indice du milieu est impair et que la valeur suivante est égale,
    le nombre solitaire se trouve avant
  * on ne détaille pas les deux autres cas de figure :)

On prendra soin de bien réfléchir aux indices de début et de fin des
différents appels récursifs

Trouver le nombre solitaire.
"""
from random import sample


def solitaire(nombres, i_debut, i_fin):
    pass


for taille in range(1, 500):
    nombres = sample(list(range(5 * taille)), taille)
    solo = nombres.pop()
    nombres = sorted(nombres * 2 + [solo])
    assert solitaire(nombres, 0, len(nombres) - 1) == solo
