"""
On donne un tableau non vide contenant N nombres entiers.

On demande la valeur minimale et la valeur maximale du tableau.

Il est possible d'effectuer cette recherche en temps linéaire en effectuant
2N comparaisons (N pour le minimum et N pour le maximum).

La méthode "Diviser pour régner" présentée ici effectue
en moyenne 1,5N comparaisons.

Pour ce faire, on recherche les minimum et maximum entre
les indices i_debut et i_fin du tableau (intialement 0 et N - 1).

Si i_debut = i_fin (une seule valeur dans la zone étudiée),
on renvoie le couple (tableau[i_debut], tableau[i_debut]).

Si i_debut + 1 = i_fin (deux valeurs dans la zone étudiée),
on compare ces valeurs et on renvoie le couple (minimum, maximum).

Dans le cas contraire :
* on calcule l'indice du milieu de la zone d'étude
* on cherche les minimum et maximum de la zone de gauche [i_debut, i_milieu]
* on cherche les minimum et maximum de la zone de droite [i_milieu + 1, i_fin]
* on compare les deux minimums obtenus (à gauche et à droite)
  et on retient le plus petit
* on compare les deux maximums obtenus (à gauche et à droite)
  et on retient le plus grand
* on renvoie ce minimum et ce maximum

"""
from random import randrange


def mini_maxi(tableau, i_debut, i_fin):
    """Renvoie le tuple (minimum, maximum) des valeurs de tableau
    comprises entre les indices i_debut et i_fin (inclus l'un et l'autre)
    """
    pass


for taille in range(10, 200):
    tableau = [randrange(0, 50) for _ in range(taille)]
    assert mini_maxi(tableau, 0, taille - 1) == (min(tableau), max(tableau))
