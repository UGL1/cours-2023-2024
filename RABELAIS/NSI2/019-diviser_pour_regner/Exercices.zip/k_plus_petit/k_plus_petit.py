"""
On se donne un tableau d'entiers non trié contenant N valeurs
et un entier k compris entre 1 et N.

On demande de renvoyer le k-ème plus petit nombre du tableau.

Par exemple, avec tableau = [26, 38, 5, 23, 30, 39, 19, 49, 44, 31]
([5, 19, 23, 26, 30, 31, 38, 39, 44, 49] une fois trié) :

* k_ieme(tableau, 1) renvoie 5 car 5 est la plus petite valeur ;
* k_ieme(tableau, 2) renvoie 19 car 19 est la 2ème plus petite valeur ;
* k_ieme(tableau, 5) renvoie 30 car 30 est la 5ème petite valeur ;
* k_ieme(tableau, 10) renvoie 49 car 5 est la plus grande valeur.


Une méthode consiste à trier l'ensemble du tableau mais ce n'est pas efficace
(inutile de trier les N - k plus grandes valeurs).

On peut utiliser une méthode du type "Diviser pour régner"
s'inspirant du tri rapide:
* on choisit une valeur pivot dans le tableau (la dernière dans le cas présent)
* on crée deux tableaux vides nommés "petits" et "grands"
* on parcourt toutes les valeurs du tableau sauf la dernière :
    - si la valeur lue est inf. ou égale au pivot on l'ajoute
      dans le petits
    - sinon l'ajoute dans le grands
* une fois le parcours terminé :
    - si k est inf. ou égal à la longueur de petits, on relance
      la recherche sur petits
    - sinon si k est égal à la longueur de petits augmentée de 1,
      on renvoie le pivot
    - sinon on relance une recherche sur le grand tableau en cherchant
      la (k - longueur(petits) - 1)-ième valeur

Supposons par exemple, dans un tableau de 500 valeurs,
que l'on cherche la 400-ième valeur.

On prend la dernière valeur comme pivot et après le parcours
on récupère 450 valeurs dans petits, la valeur pivot et 49 valeurs dans grands
(450 + 1 + 49 = 500)

La 400-ième valeur est donc dans le petit tableau.
On relance k_ieme(petits, 400)

On choisit alors la dernière valeur comme pivot
et on obtient 100 valeurs dans petits, 1 valeur pivot
et 349 dans grands (100 + 1 + 349 = 450).

La 400-ième valeur est dans le grand tableau
mais il s'agit dans ce tableau de la 299-ième valeur.
En effet, on a laissé 100 + 1 valeurs dans petits + [pivot].
On appelle donc k_ieme(grands, 299).

On choisit la dernière valeur comme pivot, on obtient 298 valeurs dans petits,
1 valeur pivot et 50 dans grands (298 + 1 + 50 = 349).
Le pivot est à la position 299 : c'est la valeur cherchée, on la renvoie.
"""

from random import randrange


def k_ieme(tableau, k):
    """Renvoie le k-ième plus petit élément du tableau"""
    pass


for taille in range(10, 20):
    rang = randrange(1, taille)
    tableau = [randrange(0, 50) for _ in range(taille)]
    assert k_ieme(tableau, rang) == sorted(tableau)[rang - 1]
