---
title: Ligne d'horizon
author: N. Revéret
---

# Présentation du problème

Un observateur regarde une ville depuis un point éloigné.

Il a devant lui une série de bâtiments ayant chacun une certaine hauteur
et une certaine étendue désignée par une abscisse de départ
et une abscisse de fin.

Un bâtiment est donc désigné par un triplet `(gauche, droite, hauteur)`.

Par exemple, en prenant `batiments = [(3, 5, 2), (6, 7, 3), (1, 8, 1)]` :

* le 1er bâtiment débute en `3` et se termine en `5`, il fait `2` de haut ;
* le 2nd bâtiment débute en `6` et se termine en `7`, il fait `3` de haut ;
* le 3ème bâtiment débute en `1` et se termine en `8`, il fait `1` de haut.
      
![Des bâtiments](batiments_exemple.png)

Remarquez que les bâtiments peuvent être situés dans des rues parallèles,
les uns derrière les autres. Ici le 3ème bâtiment est devant les deux
autres. Cet ordre n'a aucune incidence sur l'exercice.

Observés à distance, les toits de ces bâtiments dessinent une ligne d'horizon séparant la ville du ciel.

![Des bâtiments et leur ligne d'horizon](batiments_ligne_exemple.png)

**On cherche à construire cette ligne d'horizon.**

# Méthode

Une ligne d'horizon est représentée sous forme d'une liste de couple `(abscisse, hauteur)`. Chaque couple correspond à un *point de rupture* dans la ligne d'horizon.

Par exemple, la ligne d'horizon de la figure précédente est `[(1, 1), (3, 2), (5, 1), (6, 3), (7, 1), (8, 0)]` :

* en `1` on passe à la hauteur `1` ;
* en `3` on passe à la hauteur `2` ;
* en `5` on passe à la hauteur `1` ;
* en `6` on passe à la hauteur `3` ;
* en `7` on passe à la hauteur `1` ;
* en `8` on passe à la hauteur `0`.

Il est possible de construire la ligne d'horizon en utilisant une méthode « Diviser pour régner » proche du tri fusion :

* on partage les bâtiments en deux jusqu'à obtenir des listes ne contenant qu'un seul bâtiment ;
* on construit la ligne d'horizon de ces sous-listes ;
* on fusionne les sous-listes.

## 1. Diviser

Le partage est classique. La fonction `ligne_horizon` prend trois arguments : la liste des bâtiments, l'indice de début de la zone d'étude et l'indice de fin de la zone d'étude. Ces deux indices sont inclus dans la zone d'étude.

Pour partager la liste en deux, on calcule l'indice du milieu de la zone d'étude et on appelle récursivement deux fois la fonction `ligne_horizon`.

## 2. Régner

Quelle est la ligne d'horizon d'un unique bâtiment ?

Elle ne contient que deux points de rupture situés à gauche et à droite du bâtiment. Au premier, on monte à la hauteur du bâtiment, au second on redescend à zéro.

Ainsi :

```pycon
>>> ligne_horizon([(3, 5, 8)])
[(3, 8), (5, 0)]
```

![Un unique bâtiment et sa ligne d'horizon](batiments_ligne_simple.png)

## 3. Combiner

L'étape délicate est la fusion de deux lignes d'horizon.

La fonction `fusion` prend en paramètres deux lignes d'horizon triées dans l'ordre croissant des abscisses des points.

On crée tout d'abord une nouvelle liste d'horizon vide ainsi que deux variables `h_gauche` et `h_droite` permettant de stocker la hauteur actuelle des bâtiments sur chaque ligne d'horizon.

On construit ensuite la nouvelle line d'horizon en insérant à chaque étape le point de rupture ayant l'abscisse la plus faible. L'aspect trié des deux lignes d'horizon permet de trouver facilement ce point.

Deux cas se présentent :

* l'abscisse de l'un des deux points considérés est strictement inférieure à celle de l'autre point : on met à jour la hauteur de la ligne correspondante (`h_gauche` **ou** `h_droite`) et on insère le point de rupture `(abscisse, max(h_gauche, h_droite))` ;

* les deux abscisses sont égales : on met à jour `h_gauche` **et** `h_droite` et on insère le point de rupture `(abscisse, max(h_gauche, h_droite))`.

# Fonctions considérées

Le fichier `ligne_d_horizon.py` contient les fonctions suivantes :

* `dessine(batiments, fichier=None)` : dessine les bâtiments dans une figure. Cette figure peut être directement affichée ou sauvegardée. Cette fonction est **déjà rédigée**; 

* `dessine_ligne(batiments, ligne, fichier=None)` : dessine les bâtiments et la ligne d'horizon dans une figure. Cette figure peut être directement affichée ou sauvegardée. Cette fonction est **déjà rédigée**; 

* `batiments_aleatoires(n, x_maxi=40, h_maxi=10, largeur_max=5)` : renvoie une liste de `n` bâtiments aléatoires répondant aux spécifications passées en arguments. Cette fonction est **déjà rédigée**; 

* `ligne_horizon(batiments, i_debut, i_fin)` : renvoie la ligne d'horizon des bâtiments contenus dans la liste `batiments` et d'indices compris entre `i_debut` et `i_fin` (inclus l'un et l'autre). Cette fonction est **à rédiger** ;
  
* `fusion(ligne_gauche, ligne_droite)` : fusionne les deux lignes d'horizons passées en argument en une nouvelle ligne d'horizon qui est renvoyée. Les deux lignes sont initialement triées dans l'ordre croissant des abscisses des points. Cette fonction est **à rédiger**.