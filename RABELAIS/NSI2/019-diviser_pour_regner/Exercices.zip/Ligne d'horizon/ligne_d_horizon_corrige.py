import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from random import randrange


def dessine(batiments, fichier=None):
    """Dessine les batiments
    Si on fournit un nom de fichier, la figure est sauvegardée
    à cet emplacment, sinon elle est simplement affichée
    """
    x_maxi = max([droite for (_, droite, _) in batiments])
    y_maxi = max([hauteur for (_, _, hauteur) in batiments])
    fig, ax = plt.subplots()
    fig.set_size_inches(10, 5)
    ax.set_xlim(0, x_maxi + 1)
    ax.set_ylim(0, y_maxi + 1)
    ax.set_xticks(range(0, x_maxi + 1))
    ax.set_yticks(range(0, y_maxi + 1))
    plt.grid()
    couleurs = ["#%06X" % randrange(0, 0xFFFFFF) for _ in range(len(batiments))]
    for i, (gauche, droite, hauteur) in enumerate(batiments):
        ax.add_patch(
            Rectangle(
                xy=(gauche, 0),
                width=droite - gauche,
                height=hauteur,
                facecolor=couleurs[i],
                alpha=0.8,
            )
        )
    plt.tight_layout()
    if fichier is not None:
        plt.savefig(fichier)
    else:
        plt.show()


def dessine_ligne(batiments, ligne, fichier=None):
    """Dessine les batiments
    Si on fournit un nom de fichier, la figure est sauvegardée
    à cet emplacment, sinon elle est simplement affichée
    """
    x_maxi = max([droite for (_, droite, _) in batiments])
    y_maxi = max([hauteur for (_, _, hauteur) in batiments])
    fig, ax = plt.subplots()
    fig.set_size_inches(10, 5)
    ax.set_xlim(0, x_maxi + 1)
    ax.set_ylim(0, y_maxi + 1)
    ax.set_xticks(range(0, x_maxi + 1))
    ax.set_yticks(range(0, y_maxi + 1))
    plt.grid()
    couleurs = ["#%06X" % randrange(0, 0xFFFFFF) for _ in range(len(batiments))]
    for i, (gauche, droite, hauteur) in enumerate(batiments):
        ax.add_patch(
            Rectangle(
                xy=(gauche, 0),
                width=droite - gauche,
                height=hauteur,
                facecolor=couleurs[i],
                alpha=0.8,
            )
        )
    abscisses = [0]
    hauteurs = [0]
    for x, h in ligne:
        abscisses.append(x)
        hauteurs.append(hauteurs[-1])
        abscisses.append(x)
        hauteurs.append(h)
    ax.plot(abscisses[1:], hauteurs[1:], "-b", lw=3)
    plt.tight_layout()
    if fichier is not None:
        plt.savefig(fichier)
    else:
        plt.show()


def batiments_aleatoires(n, x_maxi=40, h_maxi=10, largeur_max=5):
    """Renvoie n triplets (gauche, droite, hauteur)
    avec 0 <= gauche < x_maxi
         gauche + 1 <= droite <= x_maxi
         0 <= hauteur <= h_maxi
    """
    batiments = [None] * n
    for i in range(n):
        gauche = randrange(0, x_maxi - 1)
        largeur = min(largeur_max, randrange(1, x_maxi - gauche))
        hauteur = randrange(1, h_maxi + 1)
        batiments[i] = (gauche, gauche + largeur, hauteur)
    return batiments


def fusion(ligne_gauche, ligne_droite):
    """Fusionne les deux lignes d'horizons"""
    taille_gauche = len(ligne_gauche)
    taille_droite = len(ligne_droite)
    ligne = []
    h_gauche = 0
    h_droite = 0
    i_gauche = 0
    i_droite = 0
    while i_gauche < taille_gauche and i_droite < taille_droite:
        x_gauche = ligne_gauche[i_gauche][0]
        x_droite = ligne_droite[i_droite][0]
        if x_gauche < x_droite:
            h_gauche = ligne_gauche[i_gauche][1]
            ligne.append((x_gauche, max(h_gauche, h_droite)))
            i_gauche += 1
        elif x_gauche == x_droite:
            h_gauche = ligne_gauche[i_gauche][1]
            h_droite = ligne_droite[i_droite][1]
            ligne.append((x_gauche, max(h_gauche, h_droite)))
            i_gauche += 1
            i_droite += 1
        else:
            h_droite = ligne_droite[i_droite][1]
            ligne.append((x_droite, max(h_gauche, h_droite)))
            i_droite += 1

    while i_gauche < taille_gauche:
        ligne.append(ligne_gauche[i_gauche])
        i_gauche += 1
    while i_droite < taille_droite:
        ligne.append(ligne_droite[i_droite])
        i_droite += 1

    return ligne


def ligne_horizon(batiments, i_debut, i_fin):
    """Renvoie la ligne d'horizon des batiments situés
    entre les indices i_debut et i_fin
    """
    if i_debut == i_fin:
        gauche, droite, hauteur = batiments[i_debut]
        return [
            (gauche, hauteur),
            (droite, 0),
        ]

    i_milieu = (i_debut + i_fin) // 2
    ligne_gauche = ligne_horizon(batiments, i_debut, i_milieu)
    ligne_droite = ligne_horizon(batiments, i_milieu + 1, i_fin)

    return fusion(ligne_gauche, ligne_droite)


batiments = batiments_aleatoires(10)
print(batiments)
# batiments = [(10, 15, 1), (17, 22, 4), (22, 27, 8), (27, 30, 8), (35, 37, 7)]
# batiments = [(3, 5, 2), (6, 7, 3), (1, 8, 1)]
# batiments = [(3, 5, 8)]
ligne = ligne_horizon(batiments, 0, len(batiments) - 1)
print(ligne)
dessine(batiments, "batiments.png")
dessine_ligne(batiments, ligne, "batiments_ligne.png")
